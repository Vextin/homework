Hi! 
A few things of note:

1. The program assumes you have a file named "input.txt" with the input. 
   ALTERNATIVELY, you can use './a.out myfilename.txt' to run with whatever file you want. 

2. Input is assumed to be in the format as follows, with the first number of each line representing a node, 
   and each other number in that line representing a node that is adjacent to the first. I also assume that the first node is 1, not 0, based on the sample. 
   Any number of nodes is supported, and it looks clean up to your 100th node. Past that the adj matrix is ugly, but it still works.

1 2 4 
2 1 3 
3 1 2 
4 1 2

3. I did NOT attempt the bonus questions

4. have a great day :^) 
